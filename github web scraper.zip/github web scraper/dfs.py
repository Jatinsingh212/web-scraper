from transformers import GPT2TokenizerFast, GPT2LMHeadModel

# Download and save locally
tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")
tokenizer.save_pretrained("./gpt2_local")

model = GPT2LMHeadModel.from_pretrained("gpt2")
model.save_pretrained("./gpt2_local")
